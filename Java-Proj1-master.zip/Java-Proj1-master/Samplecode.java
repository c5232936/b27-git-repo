class Simple{  
    public static void main(String args[]) throws InterruptedException{  
     Thread.sleep(5000);
     System.out.println("Hello Java updated");  
    }  
}
